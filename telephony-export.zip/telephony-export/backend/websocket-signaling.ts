// Excerpt from artifacts/api-server/src/index.ts (lines 770-812)
    await seedGuideDataIfEmpty();
  } catch (guideErr) {
    logger.error({ err: guideErr }, "Guide seed error");
  }

  const server = createServer(app);

  // ── WebSocket signaling server for WebRTC internal calls ───────────────────
  const wss = new WebSocketServer({ server, path: "/ws/telephony" });

  wss.on("connection", (ws, req) => {
    let myId: string | null = null;

    ws.on("message", (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        // Register: { type: "register", userId: "user-123" }
        if (msg.type === "register" && msg.userId) {
          myId = String(msg.userId);
          registerClient(myId, ws);
          ws.send(JSON.stringify({ type: "registered", userId: myId, peers: getOnlinePeers(myId) }));
          // Notify others
          getOnlinePeers(myId).forEach(id => sendToClient(id, { type: "peer-online", userId: myId }));
          return;
        }
        // Relay signals: offer, answer, ice-candidate, call, hangup
        const { to, ...payload } = msg;
        if (to) {
          sendToClient(String(to), { ...payload, from: myId });
        }
      } catch { /* ignore malformed */ }
    });

    ws.on("close", () => {
      if (myId) {
        unregisterClient(myId);
        getOnlinePeers().forEach(id => sendToClient(id, { type: "peer-offline", userId: myId }));
      }
    });
  });

  // Keep-alive of 1 s so connections are released quickly on restart
  server.keepAliveTimeout = 1000;
