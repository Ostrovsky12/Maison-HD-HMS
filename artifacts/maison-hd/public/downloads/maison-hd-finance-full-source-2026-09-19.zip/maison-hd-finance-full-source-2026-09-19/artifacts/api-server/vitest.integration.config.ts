import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    globals: true,
    include: ["src/tests/invoice-isolation.integration.ts"],
    testTimeout: 30_000,
    hookTimeout: 30_000,
  },
});