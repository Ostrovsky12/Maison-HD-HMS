# Telephony Module — Maison HD

## Архітектура

```
backend/
  routes/telephony.ts          — Express-маршрути: Binotel webhooks, AI summary, CRUD phone_lines / call_logs

frontend/
  pages/telephony.tsx          — Головна сторінка "Telephony AI" (дашборд дзвінків, live-статус, AI-нотатки)
  contexts/telephony-context.tsx — React-контекст: WebSocket /ws/telephony, стан дзвінків, WebRTC сигналізація

websocket/ (вбудовано в api-server/src/index.ts, рядки 777–809)
  /ws/telephony                — WebSocketServer для WebRTC peer-сигналізації (offer/answer/ICE/call/hangup)
```

## Провайдери

| Провайдер | Роль |
|-----------|------|
| **Binotel** | Основний: webhooks `call-settings` і `call-completed`, прив'язка phone_lines |
| **OpenAI**  | AI summary + sentiment analysis після завершення дзвінка |

## База даних (inline-схеми в telephony.ts)

- `telephony_settings` — налаштування на організацію (API-ключ Binotel, увімкнення AI)
- `phone_lines`        — SIP/Cloud номери з прив'язкою до internal_number
- `call_logs`          — лог дзвінків з полями `ai_summary`, `sentiment`, `duration_sec`

## WebSocket-протокол

```jsonc
// Реєстрація клієнта
{ "type": "register", "userId": "user-123" }

// Сервер → клієнт після реєстрації
{ "type": "registered", "userId": "user-123", "peers": ["user-456"] }

// Ретрансляція сигналів (offer / answer / ice-candidate / call / hangup)
{ "type": "offer", "to": "user-456", "sdp": "..." }
```

## Binotel Webhook endpoints

```
POST /api/telephony/binotel/webhook/call-settings   — вхідний дзвінок, повертає routing
POST /api/telephony/binotel/webhook/call-completed  — завершення дзвінка, тригерить AI summary
```

## Підключення до API Server

```ts
// artifacts/api-server/src/routes/index.ts
import telephonyRouter from "./telephony";
router.use(telephonyRouter);
```
