# Кабінет гостя (Guest Portal) — Maison HD

## Архітектура

```
backend/
  routes/
    guest-portal.ts     — 1 209 рядків. Всі API для гостя: check-in, check-out,
                          повідомлення, замовлення сервісів, документи, відгуки,
                          лояльність, платіжні нотифікації. Публічні ендпоінти
                          захищені токеном (guestAccessCode).
    room-concierge.ts   —  452 рядки. In-room термінал: AI-чат, замовлення,
                          адмін-відповіді, база знань.

  schema/
    reservations.ts     — Бронювання: поля guestAccessCode, checkinFormSubmitted,
                          checkinFormData.
    guests.ts           — Профіль гостя.
    hospitality.ts      — Concierge-сесії, запити, база знань.
    content.ts          — Таблиця checkinForms (шаблони форм чек-іну).

frontend/
  guest-portal/
    guest-portal.tsx    — 1 478 рядків. SPA кабінету гостя на /guest/:code:
                          wizard чек-іну, запит чек-ауту, сервіси, чат,
                          документи, рев'ю, лояльність, платежі.

  room-concierge/
    App.tsx             — Роути артефакту (/, /setup, /admin, /guest-menu, /bill, /pay).
    hooks/
      use-concierge.ts  — State machine терміналу: speech recognition, TTS,
                          polling відповідей, AI-запити.
    lib/
      api.ts            — API-клієнт /api/room-concierge/*.
    pages/
      terminal.tsx      — UI in-room терміналу.
      guest-menu.tsx    — Замовлення їжі/сервісів (1 355 рядків).
      bill.tsx          — Рахунок гостя.
      pay.tsx           — Платіжна сторінка.
      admin.tsx         — Панель персоналу: запити + база знань.
```

## Flows

### Check-In (онлайн)
1. Гість отримує посилання `/guest/<code>` (генерується при бронюванні).
2. `GET /api/guest/booking/:token` — завантаження даних бронювання.
3. Wizard заповнення: паспорт, кількість гостей, preferences, підпис.
4. `POST /api/guest/checkin/:token` — збереження форми, оновлення `checkinFormSubmitted = true`.
5. Персонал бачить дані в Booking Panel (`/api/guest/staff/bookings/:id/checkin-data`).

### Check-Out
1. Гість натискає "Запросити чек-аут" в кабінеті.
2. `POST /api/guest/checkout/:token` — запит відправляється персоналу.
3. Персонал підтверджує через HMS або Guest Experience.

### Room Concierge (in-room термінал)
1. Термінал стартує з `GET /api/room-concierge/terminal/:orgSlug/:unitId`.
2. Знаходить активне бронювання → створює/відновлює concierge-сесію.
3. Гість говорить або пише → `POST /api/room-concierge/chat` → OpenAI → відповідь.
4. Запит від гостя → `POST /api/room-concierge/requests` → адмін-черга.
5. Персонал відповідає через `/admin` → polling на терміналі.

## Ключові ендпоінти (Public, захист через token)

| Метод | Шлях | Опис |
|-------|------|------|
| GET | `/api/guest/booking/:token` | Дані бронювання |
| POST | `/api/guest/checkin/:token` | Відправити форму чек-іну |
| POST | `/api/guest/checkout/:token` | Запит чек-ауту |
| GET | `/api/guest/services/:token` | Доступні сервіси |
| POST | `/api/guest/orders/:token` | Замовити сервіс |
| GET/POST | `/api/guest/messages/:token` | Листування з персоналом |
| POST | `/api/guest/review/:token` | Залишити відгук |
| GET | `/api/guest/documents/:token` | Документи (рахунок, ваучер) |

## БД — ключові поля бронювання

```sql
-- reservations
guestAccessCode       TEXT UNIQUE  -- токен для /guest/:code
checkinFormSubmitted  BOOLEAN      -- чи заповнена форма
checkinFormData       JSONB        -- дані форми (паспорт, гості, preferences)
```

## Монтування в роутері

```ts
// artifacts/api-server/src/routes/index.ts
router.use("/guest", guestPortalRouter);       // лінія ~117
router.use("/room-concierge", roomConciergeRouter); // лінія ~165
```
