/**
 * Database connection & schema exports
 * Usage: import { db } from "@/db"
 *        import { tenants, reservations, ... } from "@/db/schema"
 */

import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export const db = drizzle(pool, { schema });

export * from "./schema";
